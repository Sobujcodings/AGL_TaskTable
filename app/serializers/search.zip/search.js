import RESTSerializer from '@ember-data/serializer/rest';

export default class SearchSerializer extends RESTSerializer {
}
