import RESTAdapter from '@ember-data/adapter/rest';

export default class SearchAdapter extends RESTAdapter {
    host = 'http://localhost:5000';
    namespace = '';
}
